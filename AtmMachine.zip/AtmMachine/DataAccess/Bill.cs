namespace AtmMachine
{
    //this class is a representation of a "Bill" object in the database
    public class Bill
    {
        public int Value { get; set; }
        public int Amount { get; set; }
    }
}